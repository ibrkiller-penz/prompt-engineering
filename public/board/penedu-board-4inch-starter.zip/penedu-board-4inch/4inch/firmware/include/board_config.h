#pragma once
// 내 보드의 실제 값은 board_config.local.h 에 두면 그것을 먼저 쓴다(git·키트에 들어가지 않는다 — tools/quick_start.ps1 이 만든다).
// 그 파일이 없으면 아래 ①~⑥ 값을 쓴다. 키트를 받은 선생님은 아래 값만 바꿔도 된다.
#if __has_include("board_config.local.h")
#include "board_config.local.h"
#else
// ── 내 보드에 맞게 바꾸는 값은 이 파일에만 있습니다 ──
// "← 내 값으로 바꾸기" 가 붙은 줄만 고치면 됩니다. 고친 뒤 다시 빌드·업로드(README 참고).
// 값을 비워 두면("") 그 기능은 꺼지고, 화면은 그대로 정상 동작합니다.

// ① 시간표 자료 주소 (끝에 / 까지)                                          ← 내 값으로 바꾸기
//   내 웹사이트의 board 폴더 주소입니다. 그 안에 index.json(시간표 목록), t/NNN.json(시간표), where.json(선생님 찾기)이 있어야 합니다.
//   예: https://내사이트.web.app/board/   (자료 만드는 법: ../common 폴더의 data-format.md 참고)
//   비워 두거나 틀려도 보드는 멈추지 않고 "시간표를 받지 못했습니다"만 보여 줍니다.
#define BOARD_BASE_URL "https://example.invalid/board/"

// ② 처음 켤 때 볼 시간표 이름                                              ← 내 값으로 바꾸기
//   index.json 목록의 name 과 같게 쓰세요(예: 교사 이름, 1학년1반, 시청각실 같은 교실 이름).
//   비워 두거나 목록에 없으면 목록의 첫 번째 시간표를 씁니다. 켠 뒤에는 ⑤ 설정 화면에서 바꿀 수 있고, 바꾼 값은 보드에 저장됩니다.
#define BOARD_DEFAULT_TT ""

// ③ 위쪽 막대의 이름 (현재는 화면에 쓰지 않는 예약 값)                      ← 내 값으로 바꾸기
#define BOARD_TITLE "교실 알림판"

// ④ 급식: 나이스 교육정보 개방 포털의 시도교육청 코드와 학교 코드             ← 내 값으로 바꾸기
//   둘 중 하나라도 비워 두면 급식 칸은 "급식을 쓰지 않습니다"로 보입니다.
//   찾기: https://open.neis.go.kr/hub/schoolInfo?Type=json&SCHUL_NM=학교이름  (결과의 ATPT_OFCDC_SC_CODE, SD_SCHUL_CODE)
#define NEIS_ATPT_CODE ""     // 시도교육청 코드 (예: 서울 B10, 부산 C10)
#define NEIS_SCHOOL_CODE ""   // 학교 코드 (숫자 7자리)

// ⑤ 수능 날짜 'YYYY-MM-DD'                                                  ← 내 값으로 바꾸기
//   시계 화면에 'D-n'을 보이고 다음 날부터 숨깁니다. 비워 두면("") 아예 보이지 않습니다.
#define SUNEUNG_DATE ""

// ⑥ 날씨·미세먼지: 학교 위치(위도, 경도) — Open-Meteo(열쇠 필요 없음)         ← 내 값으로 바꾸기
//   지도 앱에서 학교를 길게 누르면 숫자가 나옵니다. 아래는 예시(서울시청)입니다.
//   비워 두면("") 날씨 칸은 "날씨 받는 중"으로 남습니다.
#define WEATHER_LAT "37.5665"
#define WEATHER_LON "126.9780"

#endif

// 교장실·교감실 모드(볼 시간표에서 교장·교감)가 받을 학교 일정 사이트(Google Apps Script 웹앱 주소). 비워 두면 일정 칸에 안내만 보인다.
#ifndef SCHEDULE_URL
#define SCHEDULE_URL ""
#endif

// ⑦ 교시 시작 시간(1~7교시). 한 교시는 50분으로 계산합니다.                  ← 내 값으로 바꾸기
//   점심시간은 12:30~13:30 으로 고정입니다(main.cpp 의 "12:30", "13:30" 을 찾아 바꾸세요).
#ifndef BOARD_PERIOD_START
#define BOARD_PERIOD_START { "08:40", "09:40", "10:40", "11:40", "13:30", "14:40", "15:40" }
#endif
